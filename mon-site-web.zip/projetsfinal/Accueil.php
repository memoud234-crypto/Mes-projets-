<?php require_once 'connexion.php'; ?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Taulissa - Restaurant</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<nav>
  <a href="description.html" class="brand">TAULISSA</a>
  <a href="Accueil.php">Accueil</a>
  <a href="menu.html">Menu</a>
  <a href="reservation.php">Réservation</a>
  <a href="commandes.php">Commande</a>
  <a href="admin_login.php">Admin</a>
</nav>
<div class="header">
  <h1>Restaurant Taulissa</h1>
  <p>Haute Gastronomie — Djibouti | Le goût de l'exception sans compromis.</p>
</div>
<div class="container">
  <?php display_flash_message(); ?>
  <h2>La Carte du Chef</h2>
  <div class="grid-plats">
    <div class="carte-plat"><img src="https://images.unsplash.com/photo-1519984388953-d2406bc725e1?w=400" alt="Saint-Jacques"><h3>Saint-Jacques au Yuzu</h3><p>3 500 FDJ</p></div>
    <div class="carte-plat"><img src="steck.jpg" alt="Steak"><h3>Steak Premium</h3><p>5 800 FDJ</p></div>
    <div class="carte-plat"><img src="burger.jpg" alt="Burger"><h3>Burger Taulissa</h3><p>2 200 FDJ</p></div>
    <div class="carte-plat"><img src="laz.jpg" alt="Lasagne"><h3>Lasagne Maison</h3><p>2 800 FDJ</p></div>
    <div class="carte-plat"><img src="homemade-pizza-in-air-fryer.jpg" alt="Pizza"><h3>Pizza Royale</h3><p>2 400 FDJ</p></div>
    <div class="carte-plat"><img src="fruits-jus-700x438.jpg" alt="Jus"><h3>Jus de Fruits Frais</h3><p>800 FDJ</p></div>
    <div class="carte-plat"><img src="SUCHI.jpeg" alt="Sushi"><h3>Hosomaki Sushi</h3><p>3 200 FDJ</p></div>
    <div class="carte-plat"><img src="chiken-benefits-for-health.jpg" alt="Poulet"><h3>Poulet Grillé</h3><p>2 600 FDJ</p></div>
    <div class="carte-plat"><img src="crevette.jpeg" alt="Crevettes"><h3>Crevettes à l'Ail</h3><p>3 000 FDJ</p></div>
  </div>
</div>
<footer>&copy; 2026 Taulissa Djibouti — Restaurant de Prestige. Welcome everytime.</footer>
</body>
</html>
